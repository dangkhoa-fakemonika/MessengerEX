package org.example.mesex;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;

public class OtherUserProfileController {
    
    @FXML
    private Button addFriendButton;
    @FXML
    private Button blockButton;

    public void addFriend(ActionEvent actionEvent){
        
    }

}
