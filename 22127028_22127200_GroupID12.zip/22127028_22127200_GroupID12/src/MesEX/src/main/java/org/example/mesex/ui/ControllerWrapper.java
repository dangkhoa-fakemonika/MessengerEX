package org.example.mesex.ui;

import javafx.fxml.Initializable;

public interface ControllerWrapper extends Initializable {
    void myInitialize();
}
