package org.example.mesexadmin.ui;

import javafx.fxml.Initializable;

public interface ControllerWrapper extends Initializable {
    void myInitialize();
}
