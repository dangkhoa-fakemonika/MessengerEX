.jar files are submitted separately in the submission:
- release_1.zip : User application jar
- release_2.zip : Admin application jar